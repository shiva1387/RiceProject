.onLoad <- function(libname, pkgname) {
    require(methods)
    .setCAMERAOptions(pkgname)   
}

